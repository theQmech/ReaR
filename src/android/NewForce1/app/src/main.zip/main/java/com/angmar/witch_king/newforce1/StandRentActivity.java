package com.angmar.witch_king.newforce1;

import android.content.Intent;
import android.graphics.Typeface;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedWriter;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.Iterator;

public class StandRentActivity extends AppCompatActivity {
    public String myurl;
    public static String standId;
    public static String userId;
    public static String EXTRA_MESSAGE;
    TableLayout table_layout;
    private StandRentTask mTableTask = null;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        Log.v("TAG", "Inside StandRentActivity.onCreate");
        super.onCreate(savedInstanceState);
        setTitle("Bikes Available");
        setContentView(R.layout.activity_stand_rent);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        table_layout = (TableLayout) findViewById(R.id.table_layout);
//        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
//        fab.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
//                        .setAction("Action", null).show();
//            }
//        });

        standId = getIntent().getStringExtra(UserRentActivity.EXTRA_MESSAGE);
        userId = getIntent().getStringExtra("userId");
        myurl = LoginActivity.myurl;
        if (standId.contains("Nothing")){
            Log.e("MainActivity. OnCreate", "userId error");
        }
        makeHeader();
        mTableTask = new StandRentTask(standId);
        mTableTask.execute();
    }

    public void makeHeader() {
//        TODO Use Rtype to create Header
        Log.v("TAG", "Inside StandRentActivity.makeHeader");
        TableRow row = new TableRow(StandRentActivity.this);
        TableRow.LayoutParams lp = new TableRow.LayoutParams(
                TableRow.LayoutParams.MATCH_PARENT,
                TableRow.LayoutParams.WRAP_CONTENT);
        row.setLayoutParams(lp);

        TextView heading = new TextView(StandRentActivity.this);
        heading.setLayoutParams(lp);
        heading.setText("Model");
        heading.setPadding(2,2,2,2);
        heading.setTextSize(18);
        heading.setTypeface(Typeface.DEFAULT_BOLD);
        row.addView(heading);

        TextView heading0 = new TextView(StandRentActivity.this);
        heading0.setLayoutParams(lp);
        heading0.setText("Color");
        heading0.setPadding(2,2,2,2);
        heading0.setTextSize(18);
        heading0.setTypeface(Typeface.DEFAULT_BOLD);
        row.addView(heading0);

        table_layout.addView(row);
    }

    public class StandRentTask extends AsyncTask<String, Void, JSONObject> {
        private final String mstandId;
        private final String mLocation;
        StandRentTask(String username) {
            mstandId = username;
            mLocation = "";
        }

        @Override
        protected JSONObject doInBackground(String... params) {
            Log.e("standId",mstandId);
            HttpURLConnection conn = null;
            String urlLogin = myurl+ "BikeList?StandID="+mstandId;
            try {
                // Simulate network access.
                URL url = new URL(urlLogin);
//                JSONObject loginData =new JSONObject();
//                loginData.put("id", mUsername);
//                loginData.put("location",mLocation);
//                Log.e("loginData",loginData.toString());
                conn = (HttpURLConnection) url.openConnection();
//                conn.setRequestProperty("Content-Type", "application/json");
//                conn.setRequestProperty("Accept", "application/json");
                conn.setRequestMethod("GET");
//                conn.setDoInput(true);
//                conn.setDoOutput(true);
//                conn.setConnectTimeout(100);
//                conn.setReadTimeout(100);

//                OutputStream out = conn.getOutputStream();
//                BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(out));
//                StringBuilder output = new StringBuilder();
//                boolean first = true;
//
//                Iterator<String> itr = loginData.keys();
//
//                while(itr.hasNext()){
//                    String key= itr.next();
//                    Object value = loginData.get(key);
//
//                    if (first) {
//                        first = false;
//                    }
//                    else {
//                        output.append("&");
//                    }
//                    output.append(URLEncoder.encode(key, "UTF-8"));
//                    output.append("=");
//                    output.append(URLEncoder.encode(value.toString(), "UTF-8"));
//
//                }
//                writer.write(output.toString());
//
//                writer.flush();
//                writer.close();
//                out.close();

                int responseCode = conn.getResponseCode();

                if (responseCode == HttpURLConnection.HTTP_OK){
                    StringBuffer sb = new StringBuffer("");
                    InputStream in = conn.getInputStream();
                    InputStreamReader isr = new InputStreamReader(in);
                    int data = isr.read();
                    while (data != -1) {
                        char current = (char) data;
                        data = isr.read();
                        sb.append(current);
                    }
                    in.close();

                    JSONObject myob = new JSONObject(sb.toString());
                    if (myob.getString("status").contains("false")) {
                        Log.e("StandRentActivity","Wrong");
                        Log.e("Server Returned",myob.getString("message"));
                        Log.e("Data",myob.getString("data"));
                        return myob;
                    }
                    else {
                        Log.e("StandRentActivity","Present");
                        return myob;
                    }
                }
                else{
                    Log.e("StandRentActivity","Error");
                    JSONObject err =new JSONObject();
                    err.put("status","false");
                    err.put("message","Response Code:"+responseCode);
                    return err;
                }
            } catch (Exception e) {
                Log.e("StandRentActivity","Exception" + e.getLocalizedMessage());
                return null;
            } finally {
                if (conn == null) {
                    conn.disconnect();
                    Log.e("StandRentActivity","Can't Connect to the network");
                    return null;
                }
            }
        }

        @Override
        protected void onPostExecute(JSONObject myob) {
//            mTableTask = null;
            String color,model,bikeId;
//            showProgress(false)
            try {
                Log.e("StandRentActivity",myob.getString("status"));
                if (myob.getString("status").contains("true")) {
                    //build rows
                    JSONArray array = myob.getJSONArray("data");

                    for (int i = 0; i < array.length(); i++) {
                        JSONObject row = array.getJSONObject(i);
                        color = row.getString("color");
                        model = row.getString("model");
                        bikeId = row.getString("bikeid");
                        final TableRow tbrow = new TableRow(StandRentActivity.this);
                        TextView t1v = new TextView(StandRentActivity.this);
                        t1v.setText(model);
                        t1v.setTextSize(18);
                        //                t1v.setTextColor(Color.WHITE);
                        //                t1v.setGravity(Gravity.CENTER);
                        tbrow.addView(t1v);
                        TextView t2v = new TextView(StandRentActivity.this);
                        t2v.setText(color);
                        t2v.setTextSize(18);
                        //                t2v.setTextColor(Color.WHITE);
                        //                t2v.setGravity(Gravity.CENTER);
                        tbrow.addView(t2v);
                        tbrow.setTag(bikeId);
//                        tbrow.setMinimumHeight(22);
                        tbrow.setPadding(0,10,0,10);
                        tbrow.setOnClickListener ( new View.OnClickListener() {
                            @Override
                            public void onClick( View v ) {
                                //Do Stuff
                                Intent screenChange=null;
                                screenChange = new Intent(StandRentActivity.this,BikeRentActivity.class);
                                screenChange.setAction(Intent.ACTION_SEND);
                                screenChange.putExtra(StandRentActivity.EXTRA_MESSAGE, (String)tbrow.getTag());
                                screenChange.putExtra("standId", standId);
                                screenChange.putExtra("userId", userId);
                                screenChange.setType("text/plain");
                                startActivity(screenChange);
                            }
                        } );
                        table_layout.addView(tbrow);
                    }

                } else {
                    // do something
                    Log.e("Error Message",myob.getString("message"));
                }
            } catch (Exception e)
            {
                Log.e("LoginActivity","Exception" + e.getLocalizedMessage());
            }

        }
    }
}
