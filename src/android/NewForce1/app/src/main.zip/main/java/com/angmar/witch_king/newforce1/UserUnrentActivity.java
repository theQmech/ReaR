package com.angmar.witch_king.newforce1;

import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashMap;

public class UserUnrentActivity extends AppCompatActivity {
    public String myurl;
    public static String userId;
    public static String EXTRA_MESSAGE;
    public static String rentedBikeID;
    TableLayout table_layout;
    private UserRentTask mTableTask = null;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        Log.v("TAG", "Inside UserRentActivity.onCreate");
        super.onCreate(savedInstanceState);
        setTitle("Drop Locations");
        setContentView(R.layout.activity_user_rent);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        table_layout = (TableLayout) findViewById(R.id.table_layout);
//        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
//        fab.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
//                        .setAction("Action", null).show();
//            }
//        });

        userId = getIntent().getStringExtra(UserMainActivity.EXTRA_MESSAGE);
        rentedBikeID = getIntent().getStringExtra("bikeId");
        myurl = LoginActivity.myurl;
        if (userId.contains("Nothing")){
            Log.e("MainActivity. OnCreate", "userId error");
        }
        makeHeader();
        mTableTask = new UserRentTask(userId);
        mTableTask.execute();
    }

    public void makeHeader() {
//        TODO Use Rtype to create Header
        Log.v("TAG", "Inside UserRentActivity.makeHeader");
        TableRow row = new TableRow(UserUnrentActivity.this);
        TableRow.LayoutParams lp = new TableRow.LayoutParams(
                TableRow.LayoutParams.MATCH_PARENT,
                TableRow.LayoutParams.WRAP_CONTENT);
        row.setLayoutParams(lp);

        TextView heading = new TextView(UserUnrentActivity.this);
        heading.setLayoutParams(lp);
//        heading.setText("StandId");
//        heading.setPadding(2,2,2,2);
//        row.addView(heading);

//        TextView heading0 = new TextView(UserRentActivity.this);
//        heading0.setLayoutParams(lp);
//        heading0.setText("Name");
//        heading0.setPadding(2,2,2,2);
////        if(row.getParent()!=null)
////            row.getParent().removeView(row);
//        row.addView(heading0);

        TextView heading1 = new TextView(UserUnrentActivity.this);
        heading1.setLayoutParams(lp);
        heading1.setText("Address");
        heading1.setPadding(2,2,2,2);
        heading1.setTextSize(18);
        heading1.setTypeface(Typeface.DEFAULT_BOLD);
        row.addView(heading1);

//        TextView heading2 = new TextView(UserRentActivity.this);
//        heading2.setLayoutParams(lp);
//        heading2.setText("Location");
//        heading2.setPadding(2,2,2,2);
//        row.addView(heading2);

        TextView heading5 = new TextView(UserUnrentActivity.this);
        heading5.setLayoutParams(lp);
        heading5.setText("NumBikes");
        heading5.setPadding(2,2,2,2);
        heading5.setTextSize(18);
        heading5.setTypeface(Typeface.DEFAULT_BOLD);
        row.addView(heading5);
        table_layout.addView(row);
    }

    public class UserRentTask extends AsyncTask<String, Void, JSONObject> {
        private final String mUsername;
        private final String mLocation;
        UserRentTask(String username) {
            mUsername = username;
            mLocation = "";
        }

        @Override
        protected JSONObject doInBackground(String... params) {

            HttpURLConnection conn = null;
            String urlLogin = myurl+ "Stands";
            try {
                // Simulate network access.
                URL url = new URL(urlLogin);
                JSONObject loginData =new JSONObject();
                loginData.put("id", mUsername);
                loginData.put("location",mLocation);
                Log.e("loginData",loginData.toString());
                conn = (HttpURLConnection) url.openConnection();
//                conn.setRequestProperty("Content-Type", "application/json");
//                conn.setRequestProperty("Accept", "application/json");
                conn.setRequestMethod("GET");
//                conn.setRequestProperty("Content-length", "0");
//                conn.setUseCaches(false);
//                conn.setAllowUserInteraction(false);
//                conn.setDoInput(true);
//                conn.setDoOutput(true);
//                conn.setConnectTimeout(100000);
//                conn.setReadTimeout(100000);
//                conn.connect();
//                HttpClient httpclient = new DefaultHttpClient();
////
//                // make GET request to the given URL
//                HttpResponse httpResponse = httpclient.execute(new HttpGet(url));


//                OutputStream out = conn.getOutputStream();
//                BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(out));
//                StringBuilder output = new StringBuilder();
                boolean first = true;

//                Iterator<String> itr = loginData.keys();
//
//                while(itr.hasNext()){
//                    String key= itr.next();
//                    Object value = loginData.get(key);
//
//                    if (first) {
//                        first = false;
//                    }
//                    else {
//                        output.append("&");
//                    }
//                    output.append(URLEncoder.encode(key, "UTF-8"));
//                    output.append("=");
//                    output.append(URLEncoder.encode(value.toString(), "UTF-8"));
//
//                }
//                writer.write(output.toString());
//
//                writer.flush();
//                writer.close();
//                out.close();
                Log.e("HTTP Response",conn.getResponseMessage());
                int responseCode = conn.getResponseCode();
                if (responseCode == HttpURLConnection.HTTP_OK){
                    StringBuffer sb = new StringBuffer("");
                    InputStream in = conn.getInputStream();
                    InputStreamReader isr = new InputStreamReader(in);
                    int data = isr.read();
                    while (data != -1) {
                        char current = (char) data;
                        data = isr.read();
                        sb.append(current);
                    }
                    in.close();

                    JSONObject myob = new JSONObject(sb.toString());
                    if (myob.getString("status").contains("false")) {
                        Log.e("UserRentActivity","Wrong");
                        Log.e("Server Returned",myob.getString("message"));
                        Log.e("Data",myob.getString("data"));
                        return myob;
                    }
                    else {
                        Log.e("LoginActivity","Present");
                        return myob;
                    }
                }
                else{
                    Log.e("LoginActivity","Error");
                    JSONObject err =new JSONObject();
                    err.put("status","false");
                    err.put("message","Response Code:"+responseCode);
                    return err;
                }
            } catch (Exception e) {
                Log.e("LoginActivity","Exception" + e.getLocalizedMessage());
                return null;
            } finally {
                if (conn == null) {
                    conn.disconnect();
                    Log.e("LoginActivity","Can't Connect to the network");
                    return null;
                }
            }
        }

        @Override
        protected void onPostExecute(JSONObject myob) {
            mTableTask = null;
            String name,address,location,numbikes,standId;
//            showProgress(false)
            try {
                Log.e("UserRentTask",myob.getString("status"));
                if (myob.getString("status").contains("true")) {
                    //build rows
                    JSONArray array = myob.getJSONArray("data");

                    for (int i = 0; i < array.length(); i++) {
                        JSONObject row = array.getJSONObject(i);
                        // name = row.getString("name");
                        address = row.getString("address");
                        location = row.getString("location");
                        numbikes = row.getString("numbikes");
                        standId = row.getString("standid");
                        final TableRow tbrow = new TableRow(UserUnrentActivity.this);
//                        TextView t1v = new TextView(UserRentActivity.this);
//                        t1v.setText(standId);
                        //                t1v.setTextColor(Color.WHITE);
                        //                t1v.setGravity(Gravity.CENTER);
//                        tbrow.addView(t1v);
//                        TextView t2v = new newTextView(UserRentActivity.this);
//                        t2v.setText(name);
//                        //                t2v.setTextColor(Color.WHITE);
//                        //                t2v.setGravity(Gravity.CENTER);
//                        tbrow.addView(t2v);
                        TextView t3v = new TextView(UserUnrentActivity.this);
                        t3v.setText(address);
                        t3v.setTextSize(18);
                        //                t3v.setTextColor(Color.WHITE);
                        //                t3v.setGravity(Gravity.CENTER);
                        tbrow.addView(t3v);
//                        TextView t4v = new TextView(UserRentActivity.this);
//                        t4v.setText(location);
//                        //                t4v.setTextColor(Color.WHITE);
//                        //                t4v.setGravity(Gravity.CENTER);
//                        tbrow.addView(t4v);
                        TextView t5v = new TextView(UserUnrentActivity.this);
                        t5v.setText(numbikes);
                        t5v.setTextSize(18);
                        tbrow.setPadding(0,10,0,10);
                        //                t4v.setTextColor(Color.WHITE);
                        //                t4v.setGravity(Gravity.CENTER);
                        tbrow.addView(t5v);
                        tbrow.setTag(standId);
//                        tbrow.setMinimumHeight(22);
                        tbrow.setOnClickListener ( new View.OnClickListener() {
                            @Override
                            public void onClick( View v ) {
                                //Do Stuff
//                                Intent screenChange=null;
//                                screenChange = new Intent(UserUnrentActivity.this,StandRentActivity.class);
//                                screenChange.setAction(Intent.ACTION_SEND);
//                                screenChange.putExtra(UserUnrentActivity.EXTRA_MESSAGE, (String)tbrow.getTag());
//                                screenChange.putExtra("userId",userId);
//                                screenChange.setType("text/plain");
//                                startActivity(screenChange);

                                AlertDialog.Builder builder = new AlertDialog.Builder(UserUnrentActivity.this);
                                builder.setTitle("Confirm");
                                builder.setMessage("Unrent bike?");
                                builder.setPositiveButton("OK",
                                        new DialogInterface.OnClickListener() {
                                            public void onClick(DialogInterface dialog,
                                                                int which) {
                                                BikeUnrentTask munrentTask = new BikeUnrentTask((String)tbrow.getTag());
                                                munrentTask.execute();
                                                finish();
                                            }
                                        });
                                AlertDialog dialog = builder.create();

                                dialog.show();
                                dialog.getButton(dialog.BUTTON_POSITIVE).setTextColor(Color.BLUE);
                            }
                        } );
                        table_layout.addView(tbrow);
                    }

                } else {
                    // do something
                    Log.e("Error Message",myob.getString("message"));
                }
            } catch (Exception e)
            {
                Log.e("LoginActivity","Exception" + e.getLocalizedMessage());
            }

        }
    }

    public class BikeUnrentTask extends AsyncTask<String, Void, String> {
        private final String mStandId;
        BikeUnrentTask(String username) {
            mStandId = username;
        }

        @Override
        protected String doInBackground(String... params) {
            Log.e("standId",mStandId);
            if(rentedBikeID == null) {
                return new String("false:No Bike to unrent");
            }
            HashMap<String , String> args = new HashMap<>();
            args.put("BikeID", rentedBikeID);
            args.put("StandID",mStandId);
            args.put("UserID",userId);
            args.put("Op","unrent");
            Log.e("args",args.toString());
            String urlLogin = myurl+ "RentOp";
            String sb = Helper.getResponse("POST",urlLogin,args);
            try {
                JSONObject myob = new JSONObject(sb.toString());
                if (myob.getString("status").contains("false")) {
                    Log.e("LoginActivity","Wrong");
                    return new String("false:"+ myob.getString("message"));
                }
                else {
                    Log.e("LoginActivity","Present");

                    return sb.toString();
                }
//                }
//                else{
//                    Log.e("LoginActivity","Error");
//                    return new String("false: "+ responseCode);
//                }
            } catch (Exception e) {
                Log.e("LoginActivity","Exception" + e.getLocalizedMessage());
                return new String("false:Exception Occured " + e.getLocalizedMessage());
            }
//            finally {
//                if (conn == null) {
//                    conn.disconnect();
//                    Log.e("LoginActivity", "Can't Connect to the network");
//                    return new String("Can't Connect");
//                }
//            }
        }

        @Override
        protected void onPostExecute(String res) {
            Intent add = new Intent(UserUnrentActivity.this, UserMainActivity.class);
            add.putExtra("userId", userId);
            if(res.startsWith("false")) {
                add.putExtra("rented", rentedBikeID);
                Helper.makeToast(getApplicationContext(),res.substring(6));
            }
            else {
                Helper.makeToast(getApplicationContext(),"Bike Successfully Unrented");
//                try {
//                    JSONObject myob = new JSONObject(res);
//                    if(myob.getJSONArray("data").length()>0) {
//                        add.putExtra("rented", null);
//                    }
//                    else {
//                    }
//                } catch (JSONException e) {
//                    e.printStackTrace();
//                }

            }
            startActivity(add);
        }
    }
}